import 'package:flutter_dotenv/flutter_dotenv.dart';

final openAiKey = dotenv.env['platzhalter'];
